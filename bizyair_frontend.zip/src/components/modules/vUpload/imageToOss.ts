import OSS from 'ali-oss'
import { oss_sign } from '@/api/public'
export function base64ToFile(base64: string, filename: string, mimeType: any) {
  const byteCharacters = atob(base64.split(',')[1]);
  const byteNumbers = new Array(byteCharacters.length);
  for (let i = 0; i < byteCharacters.length; i++) {
    byteNumbers[i] = byteCharacters.charCodeAt(i);
  }
  const byteArray = new Uint8Array(byteNumbers);
  const blob = new Blob([byteArray], { type: mimeType || base64.split(':')[1].split(';')[0] });
  return new File([blob], filename, { type: blob.type });
}
export const formatToWebp = (file: File) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = (e) => {
      const img = new Image()
      img.onload = () => {
        const canvas = document.createElement('canvas')
        const ctx = canvas.getContext('2d')
        canvas.width = img.width
        canvas.height = img.height
        ctx?.drawImage(img, 0, 0)
        const webpDataUrl = canvas.toDataURL('image/webp')
        resolve(webpDataUrl)
        console.log(base64ToFile(webpDataUrl, `${file.name}.webp`, 'image/webp'))
      }
      img.src = e.target?.result as string
    }
    reader.onerror = (e) => {
      reject(e)
    }
    reader.readAsDataURL(file)
  })
}

function creatClient(accessFile: any) {
  const accessKeyId = accessFile.file.access_key_id
  const accessKeySecret = accessFile.file.access_key_secret
  const bucket = accessFile.storage.bucket
  const stsToken = accessFile.file.security_token
  const region = accessFile.storage.region

  return new OSS({
    accessKeyId,
    accessKeySecret,
    stsToken,
    bucket,
    region,
    secure: true
  })
}
export async function imageToOss(file: File, dir: string) {
  const ossData = await oss_sign('123')
  const client = creatClient({ ...ossData.data })
  const res = await client.put(`${dir}/${file.name}`, file)

  return res
}