export { default as ModelDetail } from './Index.vue'
