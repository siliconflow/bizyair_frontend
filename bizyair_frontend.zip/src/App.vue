<template>
  <div class="shadcn-root flex w-full">
    <!-- <btnExample /> -->
    <btnProfile v-if="statusStore.isLogin" />
    <btnApiKey v-else />
    <btnCommunity />
    <btnModel />
    <btnWorkflow />
    <btnNews />
    <apiKeyDialog />
  </div>
</template>
<script setup lang="ts">
  // import btnExample from '@/views/btnExample/index.vue'
  import btnApiKey from '@/views/btnApiKey/index.vue'
  import btnProfile from '@/views/btnProfile/index.vue'
  import btnCommunity from '@/views/btnCommunity/index.vue'
  import btnModel from '@/views/btnModel/index.vue'
  import btnWorkflow from '@/views/btnWorkflow/index.vue'
  import btnNews from '@/views/btnNews/index.vue'
  import apiKeyDialog from '@/views/btnApiKey/apiKeyDialog.vue'
  import { useStatusStore } from '@/stores/userStatus'
  import { provide } from 'vue'

  const statusStore = useStatusStore()
  statusStore.loginRefresh()
  statusStore.sendSocket(res => {
    provide('socket', res)
  })
</script>
<style scoped></style>
