module.exports = {
  semi: false,
  singleQuote: true,
  printWidth: 100,
  trailingComma: 'none',
  arrowParens: 'avoid',
  endOfLine: 'auto',
  tabWidth: 2,
  useTabs: false,
  vueIndentScriptAndStyle: true
} 