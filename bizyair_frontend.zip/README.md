# BizYair Frontend

# Getting Started

``` bash
git clone https://github.com/siliconflow/bizyair_frontend.git
cd bizyair_frontend 
# 安装依赖
npm install
# prettier 
npm run format 
# eslint 
npx eslint src
# release frontend 
npm run dev
```

### Installation and Setup
